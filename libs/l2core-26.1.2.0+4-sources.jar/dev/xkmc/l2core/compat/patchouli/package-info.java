@org.jspecify.annotations.NullMarked

package dev.xkmc.l2core.compat.patchouli;

